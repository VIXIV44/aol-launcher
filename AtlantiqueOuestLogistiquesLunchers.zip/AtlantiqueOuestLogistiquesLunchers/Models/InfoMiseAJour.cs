namespace AtlantiqueOuestLogistiquesLunchers.Models
{
    public class InfoMiseAJour
    {
        public string DerniereVersion { get; set; } = string.Empty;
        public string UrlTelechargementExe { get; set; } = string.Empty;
        public string? Notes { get; set; }
    }
}
