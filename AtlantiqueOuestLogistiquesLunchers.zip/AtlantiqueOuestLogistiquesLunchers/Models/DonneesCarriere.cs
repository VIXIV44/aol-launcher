using System;
using System.Collections.Generic;

namespace AtlantiqueOuestLogistiquesLunchers.Models
{
    public class TrajetHistorique
    {
        public DateTime Date { get; set; }
        public double DistanceKm { get; set; }
        public double Gain { get; set; }
        public string VilleDepart { get; set; } = string.Empty;
        public string EntrepriseDepart { get; set; } = string.Empty;
        public string VilleArrivee { get; set; } = string.Empty;
        public string EntrepriseArrivee { get; set; } = string.Empty;
        public double DureeMinutes { get; set; }
        public bool AUtiliseFerry { get; set; }
        public double RevenuJeu { get; set; }
        public double DommagesCargoPourcent { get; set; }
        public string CheminCmr { get; set; } = string.Empty;
    }

    /// <summary>
    /// Statistiques de carrière stockées localement (fichier JSON), propres
    /// à chaque joueur / PC — portée "locale" choisie pour ce système.
    /// </summary>
    public class DonneesCarriere
    {
        public double DistanceTotaleKm { get; set; }
        public double GainsTotaux { get; set; }
        public List<TrajetHistorique> Historique { get; set; } = new();
    }
}
