namespace AtlantiqueOuestLogistiquesLunchers.Models
{
    /// <summary>
    /// Snapshot de la mission en cours, sauvegardé sur disque en continu pendant
    /// le trajet. Permet de reprendre la distance déjà parcourue si le jeu (ou
    /// le launcher) est fermé puis rouvert avant la livraison.
    /// </summary>
    public class MissionEnCours
    {
        public string VilleDepart { get; set; } = string.Empty;
        public string EntrepriseDepart { get; set; } = string.Empty;
        public string VilleArrivee { get; set; } = string.Empty;
        public string EntrepriseArrivee { get; set; } = string.Empty;
        public double DistancePrevueKm { get; set; }
        public double DistanceParcourueKm { get; set; }
        public bool AUtiliseFerry { get; set; }
        public string DebutReel { get; set; } = string.Empty; // ISO 8601
    }
}
