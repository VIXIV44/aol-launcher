namespace AtlantiqueOuestLogistiquesLunchers.Models
{
    public class ModManifestEntry
    {
        public string NomFichier { get; set; } = string.Empty;
        public string UrlTelechargement { get; set; } = string.Empty;
        public string HashAttendu { get; set; } = string.Empty;
    }

    public enum EtapeLauncher
    {
        ModsManquants,
        ModsAJour
    }
}
