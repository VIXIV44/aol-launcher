using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AtlantiqueOuestLogistiquesLunchers.Services
{
    public class StatutServeur
    {
        public bool EnLigne { get; set; }
        public int NombreJoueurs { get; set; }
        public int JoueursMax { get; set; }
        public string NomServeur { get; set; } = string.Empty;
    }

    /// <summary>
    /// Interroge le serveur dédié ETS2 en direct via le protocole de requête
    /// standard (A2S_INFO, le même protocole que les serveurs Source/Steam).
    /// Gère l'étape de "challenge" (S2C_CHALLENGE) exigée par les serveurs
    /// récents avant de répondre — la même mécanique utilisée par la
    /// librairie "gamedig".
    ///
    /// NOTE : ceci interroge directement le serveur de jeu, pas le panel
    /// d'hébergement (fly-serv.com) — ce dernier n'expose pas d'API publique
    /// accessible sans authentification.
    /// </summary>
    public class ServerStatusService
    {
        private readonly string _adresseIp;
        private readonly int _portQuery;
        private readonly int _timeoutMs;

        public ServerStatusService(string adresseIp, int portQuery, int timeoutMs = 3000)
        {
            _adresseIp = adresseIp;
            _portQuery = portQuery;
            _timeoutMs = timeoutMs;
        }

        public async Task<StatutServeur> InterrogerAsync()
        {
            if (string.IsNullOrWhiteSpace(_adresseIp) || _portQuery <= 0)
                return new StatutServeur { EnLigne = false };

            try
            {
                using var client = new UdpClient();
                client.Connect(_adresseIp, _portQuery);

                // 1er envoi : requête A2S_INFO sans challenge
                await EnvoyerAsync(client, ConstruireRequeteInfo(null));
                byte[] reponse = await RecevoirAvecTimeoutAsync(client);

                // Si le serveur répond par un challenge (0x41 'A'), on relance
                // la requête en y ajoutant le challenge reçu.
                if (reponse.Length >= 5 && reponse[4] == 0x41)
                {
                    byte[] challenge = new byte[4];
                    Buffer.BlockCopy(reponse, 5, challenge, 0, 4);

                    await EnvoyerAsync(client, ConstruireRequeteInfo(challenge));
                    reponse = await RecevoirAvecTimeoutAsync(client);
                }

                return AnalyserReponse(reponse);
            }
            catch
            {
                // Timeout, port fermé, ou serveur injoignable => considéré hors ligne
                return new StatutServeur { EnLigne = false };
            }
        }

        private static async Task EnvoyerAsync(UdpClient client, byte[] donnees)
        {
            await client.SendAsync(donnees, donnees.Length);
        }

        private async Task<byte[]> RecevoirAvecTimeoutAsync(UdpClient client)
        {
            using var cts = new CancellationTokenSource(_timeoutMs);
            var resultat = await client.ReceiveAsync().WaitAsync(cts.Token);
            return resultat.Buffer;
        }

        private static byte[] ConstruireRequeteInfo(byte[]? challenge)
        {
            // FF FF FF FF 54 "Source Engine Query" 00 [+ 4 octets de challenge en option]
            var entete = new byte[] { 0xFF, 0xFF, 0xFF, 0xFF, 0x54 };
            var chaine = Encoding.ASCII.GetBytes("Source Engine Query\0");
            int tailleChallenge = challenge?.Length ?? 0;

            var requete = new byte[entete.Length + chaine.Length + tailleChallenge];
            Buffer.BlockCopy(entete, 0, requete, 0, entete.Length);
            Buffer.BlockCopy(chaine, 0, requete, entete.Length, chaine.Length);

            if (challenge != null)
                Buffer.BlockCopy(challenge, 0, requete, entete.Length + chaine.Length, challenge.Length);

            return requete;
        }

        private static StatutServeur AnalyserReponse(byte[] donnees)
        {
            // En-tête : FF FF FF FF 49 (0x49 = 'I' = réponse A2S_INFO)
            if (donnees.Length < 6 || donnees[4] != 0x49)
                return new StatutServeur { EnLigne = false };

            int position = 6; // saute l'en-tête + le champ "protocol version"

            string LireChaine()
            {
                int debut = position;
                while (position < donnees.Length && donnees[position] != 0x00)
                    position++;

                string valeur = Encoding.UTF8.GetString(donnees, debut, position - debut);
                position++; // saute le \0
                return valeur;
            }

            string nomServeur = LireChaine();
            LireChaine(); // map
            LireChaine(); // dossier du jeu
            LireChaine(); // description du jeu

            position += 2; // App ID (2 octets)

            byte joueurs = donnees[position++];
            byte joueursMax = donnees[position++];

            return new StatutServeur
            {
                EnLigne = true,
                NombreJoueurs = joueurs,
                JoueursMax = joueursMax,
                NomServeur = nomServeur
            };
        }
    }
}
