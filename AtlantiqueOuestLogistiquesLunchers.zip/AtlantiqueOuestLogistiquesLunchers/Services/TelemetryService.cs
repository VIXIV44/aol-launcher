using System;
using System.Globalization;
using System.IO;
using System.Text.Json;
using SCSSdkClient;
using SCSSdkClient.Object;
using AtlantiqueOuestLogistiquesLunchers.Models;

namespace AtlantiqueOuestLogistiquesLunchers.Services
{
    public class EtatTelemetrie
    {
        public bool SdkActif { get; set; }
        public double VitesseKmh { get; set; }
        public bool EnTrajet { get; set; }
        public bool EnFerry { get; set; }
        public double GainTrajetActuel { get; set; }
        public double DistancePrevueTrajetKm { get; set; }
        public double DommagesCargoPourcent { get; set; }

        public string VilleDepart { get; set; } = string.Empty;
        public string EntrepriseDepart { get; set; } = string.Empty;
        public string VilleArrivee { get; set; } = string.Empty;
        public string EntrepriseArrivee { get; set; } = string.Empty;

        /// <summary>Distance cumulée UNIQUEMENT parcourue en mission (OnJob actif), pas en mode libre.</summary>
        public double DistanceSessionKm { get; set; }

        /// <summary>Durée réelle écoulée depuis le début de la mission en cours.</summary>
        public TimeSpan DureeMission { get; set; }
    }

    /// <summary>Informations complètes transmises une fois une mission livrée avec succès.</summary>
    public class MissionTermineeInfo
    {
        public double DistanceKm { get; set; }
        public double Gain { get; set; }
        public string VilleDepart { get; set; } = string.Empty;
        public string EntrepriseDepart { get; set; } = string.Empty;
        public string VilleArrivee { get; set; } = string.Empty;
        public string EntrepriseArrivee { get; set; } = string.Empty;
        public TimeSpan Duree { get; set; }
        public bool AUtiliseFerry { get; set; }
        public double DommagesCargoPourcent { get; set; }
    }

    /// <summary>
    /// Se connecte au plug-in de télémétrie officiel SCS (via la librairie
    /// cliente C# de RenCloud, "SCSSdkClient") pour lire en direct la vitesse,
    /// l'odomètre et les infos de trajet du camion, et gère tout le cycle de
    /// vie d'une mission (début -> suivi -> livraison) plutôt qu'une session
    /// démarrée/arrêtée manuellement.
    ///
    /// PRÉREQUIS CÔTÉ JOUEUR (voir README) :
    /// 1. Le plug-in natif (scs-telemetry.dll) est copié automatiquement par
    ///    le launcher dans le dossier plugins du jeu.
    /// 2. La librairie cliente C# (SCSSdkClient.dll) est déjà dans Libs/.
    ///
    /// NOTE : les noms de propriétés utilisés (CitySource, CompanySource,
    /// JobValues.PlannedDistanceKm, SpecialEventsValues.Ferry...) s'appuient sur
    /// la documentation communautaire du projet — à ajuster si le compilateur
    /// indique un nom différent une fois la vraie DLL en place.
    /// </summary>
    public class TelemetryService : IDisposable
    {
        private readonly SCSSdkTelemetry _client = new SCSSdkTelemetry();
        private readonly string _cheminMissionEnCours =
            Path.Combine(AppContext.BaseDirectory, "mission_en_cours.json");

        // L'évènement Data peut être déclenché depuis un thread d'arrière-plan ;
        // ce verrou évite que deux appels concurrents ne corrompent les compteurs
        // partagés (ce qui provoquait des sauts de vitesse/distance erratiques).
        private readonly object _verrou = new object();

        private double? _odometreReference;
        private DateTime? _horodatageReference;
        private double? _dernierOdometreConnu;

        // Valeur persistante (pas une variable locale remise à 0 à chaque appel) :
        // sans ça, chaque tick sans nouvelle donnée republiait une vitesse à 0,
        // créant des sauts du type 0/170/40/0/140... au lieu d'une valeur stable.
        private double _vitesseKmhActuelle;

        private bool _missionActive;
        private double _distanceMissionKm;
        private bool _missionAUtiliseFerry;
        private double _dernierRevenuConnu;
        private double _dernierDommagesConnus;
        private DateTime _debutMission;

        // Évite d'écrire sur le disque à chaque tick (toutes les ~100ms) :
        // on ne sauvegarde la mission en cours qu'au maximum 1x/5 secondes.
        private DateTime _dernierEnregistrement = DateTime.MinValue;

        public event Action<EtatTelemetrie>? SurMiseAJour;

        /// <summary>Déclenché une fois qu'une mission est livrée avec succès (revenu perçu).</summary>
        public event Action<MissionTermineeInfo>? SurMissionTerminee;

        public TelemetryService()
        {
            _client.Data += (SCSTelemetry data, bool nouvelleValeur) =>
            {
                EtatTelemetrie etat;

                lock (_verrou)
                {
                    // OnJob (SpecialEventsValues) semble être un évènement ponctuel
                    // (vrai un seul instant à l'acceptation du contrat), pas un état
                    // soutenu tout le long du trajet -> il fait rater presque toute
                    // la distance. PlannedDistanceKm, lui, ne peut être non-nul que
                    // pendant toute la durée réelle d'un contrat actif : plus fiable
                    // pour savoir si on est "en mission" en continu.
                    bool onJob = data.JobValues.PlannedDistanceKm > 0;
                    bool cargoCharge = data.JobValues.CargoLoaded;
                    bool enFerry = data.SpecialEventsValues.Ferry;
                    DateTime maintenant = DateTime.UtcNow;

                    string villeDepart = data.JobValues.CitySource;
                    string entrepriseDepart = data.JobValues.CompanySource;
                    string villeArrivee = data.JobValues.CityDestination;
                    string entrepriseArrivee = data.JobValues.CompanyDestination;

                    if (data.SdkActive)
                    {
                        double odometreActuel = data.TruckValues.CurrentValues.DashboardValues.Odometer;

                        // --- Début d'une nouvelle mission ---
                        if (onJob && !_missionActive)
                        {
                            DemarrerMission(villeDepart, entrepriseDepart, villeArrivee, entrepriseArrivee,
                                data.JobValues.PlannedDistanceKm);
                        }

                        if (nouvelleValeur)
                        {
                            // --- Distance : garde-fou simple et indépendant du temps ---
                            // On ne rejette un delta que s'il est négatif (retour en
                            // arrière du jeu) ou absurdement grand pour un seul tick
                            // (>2 km d'un coup = vraisemblablement un glitch/téléportation,
                            // pas une vitesse réelle même très élevée). Aucune dépendance
                            // à l'écart de temps mesuré, qui peut être bruité si les
                            // évènements arrivent par rafales irrégulières.
                            if (_dernierOdometreConnu.HasValue)
                            {
                                double deltaKm = odometreActuel - _dernierOdometreConnu.Value;
                                if (deltaKm > 0 && deltaKm <= 2.0 && onJob && cargoCharge && _missionActive)
                                    _distanceMissionKm += deltaKm;
                            }
                            _dernierOdometreConnu = odometreActuel;

                            // --- Vitesse affichée : fenêtre glissante d'au moins 1
                            // seconde réelle, pour lisser tout bruit de timing plutôt
                            // que de calculer sur un écart minuscule et instable. ---
                            if (_odometreReference.HasValue && _horodatageReference.HasValue)
                            {
                                double deltaHeuresFenetre = (maintenant - _horodatageReference.Value).TotalHours;

                                if (deltaHeuresFenetre >= (3.0 / 3600.0)) // au moins 3 secondes réelles
                                {
                                    double deltaKmFenetre = odometreActuel - _odometreReference.Value;
                                    double vitesseImplicite = deltaKmFenetre / deltaHeuresFenetre;

                                    // Garde-fou large : au-delà de 150 km/h c'est
                                    // improbable pour un camion -> on garde la dernière
                                    // valeur stable plutôt que d'afficher un pic aberrant.
                                    if (deltaKmFenetre >= 0 && vitesseImplicite <= 150)
                                        _vitesseKmhActuelle = vitesseImplicite;

                                    _odometreReference = odometreActuel;
                                    _horodatageReference = maintenant;
                                }
                            }
                            else
                            {
                                _odometreReference = odometreActuel;
                                _horodatageReference = maintenant;
                            }
                        }

                        if (onJob && enFerry)
                            _missionAUtiliseFerry = true;

                        // On garde en mémoire le dernier revenu connu PENDANT que
                        // le contrat est actif : au moment exact où il se termine,
                        // Income semble déjà retombé à 0 (comme PlannedDistanceKm),
                        // ce qui faisait échouer le contrôle "revenu > 0" et donc
                        // ignorer silencieusement des livraisons pourtant réussies.
                        if (onJob && data.JobValues.Income > 0)
                            _dernierRevenuConnu = data.JobValues.Income;

                        // Même logique pour le % de dégâts cargo (dispo tout du
                        // long, pas seulement à la toute fin) : purement informatif,
                        // on n'essaie pas de recalculer la pénalité en €.
                        if (onJob)
                            _dernierDommagesConnus = data.JobValues.CargoValues.CargoDamage * 100.0;

                        if (onJob && _missionActive && (maintenant - _dernierEnregistrement).TotalSeconds >= 5)
                        {
                            SauvegarderMissionEnCours(villeDepart, entrepriseDepart, villeArrivee, entrepriseArrivee,
                                data.JobValues.PlannedDistanceKm);
                            _dernierEnregistrement = maintenant;
                        }

                        // --- Fin de mission (livraison) ---
                        if (!onJob && _missionActive)
                        {
                            // Si Income affiche encore une valeur au tick exact où
                            // le contrat se termine, c'est peut-être le montant final
                            // (après bonus/pénalités) tout juste recalculé -> on le
                            // préfère. Sinon on retombe sur le dernier connu pendant
                            // le trajet (le prix annoncé du contrat).
                            double revenuFinal = data.JobValues.Income > 0 ? data.JobValues.Income : _dernierRevenuConnu;
                            TerminerMission(revenuFinal);
                        }
                    }
                    else
                    {
                        // Jeu pas actif (menu, chargement...) : la vitesse affichée
                        // retombe à 0, mais on ne touche pas à l'odomètre de référence
                        // ni à la distance déjà accumulée.
                        _vitesseKmhActuelle = 0;
                    }

                    etat = new EtatTelemetrie
                    {
                        SdkActif = data.SdkActive,
                        VitesseKmh = _vitesseKmhActuelle,
                        EnTrajet = onJob,
                        EnFerry = enFerry,
                        GainTrajetActuel = data.JobValues.Income,
                        DistancePrevueTrajetKm = data.JobValues.PlannedDistanceKm,
                        VilleDepart = villeDepart,
                        EntrepriseDepart = entrepriseDepart,
                        VilleArrivee = villeArrivee,
                        EntrepriseArrivee = entrepriseArrivee,
                        DistanceSessionKm = _distanceMissionKm,
                        DommagesCargoPourcent = _dernierDommagesConnus,
                        DureeMission = _missionActive ? (maintenant - _debutMission) : TimeSpan.Zero
                    };
                }

                SurMiseAJour?.Invoke(etat);
            };

            RepredreMissionEnCoursSiPresente();
        }

        private void DemarrerMission(string villeDepart, string entrepriseDepart, string villeArrivee,
            string entrepriseArrivee, double distancePrevueKm)
        {
            _missionActive = true;
            _missionAUtiliseFerry = false;
            _dernierRevenuConnu = 0;
            _dernierDommagesConnus = 0;
            _debutMission = DateTime.UtcNow;

            // Si une mission identique était déjà en cours de suivi (persistée
            // avant une fermeture du jeu/launcher), on reprend sa distance déjà
            // parcourue plutôt que de repartir de zéro. Deux garde-fous pour
            // éviter qu'une ancienne mission ne se fasse passer pour la nouvelle :
            // - toutes les villes/entreprises doivent être non vides ET identiques
            // - la mission persistée doit être récente (< 30 min), sinon elle est
            //   considérée comme abandonnée et on repart de zéro.
            var reprise = ChargerMissionEnCours();
            bool infosCompletes = !string.IsNullOrWhiteSpace(villeDepart) && !string.IsNullOrWhiteSpace(entrepriseDepart)
                && !string.IsNullOrWhiteSpace(villeArrivee) && !string.IsNullOrWhiteSpace(entrepriseArrivee);
            bool recente = reprise != null && EssayerParserDateUtc(reprise.DebutReel, out var debutReprise)
                && (DateTime.UtcNow - debutReprise).TotalMinutes < 30;

            if (reprise != null && infosCompletes && recente
                && reprise.VilleDepart == villeDepart && reprise.EntrepriseDepart == entrepriseDepart
                && reprise.VilleArrivee == villeArrivee && reprise.EntrepriseArrivee == entrepriseArrivee)
            {
                _distanceMissionKm = reprise.DistanceParcourueKm;
                _missionAUtiliseFerry = reprise.AUtiliseFerry;
                if (EssayerParserDateUtc(reprise.DebutReel, out var debut))
                    _debutMission = debut;
            }
            else
            {
                _distanceMissionKm = 0;
                SupprimerMissionEnCours();
            }

            SauvegarderMissionEnCours(villeDepart, entrepriseDepart, villeArrivee, entrepriseArrivee, distancePrevueKm);
        }

        private void TerminerMission(double revenu)
        {
            _missionActive = false;

            // On enregistre dès qu'une distance réelle a été parcourue — on ne
            // conditionne plus ça à un revenu positif, pour ne jamais perdre
            // silencieusement une livraison si ce champ est mal lu à l'instant T.
            if (_distanceMissionKm > 0)
            {
                var infos = ChargerMissionEnCours();
                SurMissionTerminee?.Invoke(new MissionTermineeInfo
                {
                    DistanceKm = _distanceMissionKm,
                    Gain = revenu,
                    VilleDepart = infos?.VilleDepart ?? "",
                    EntrepriseDepart = infos?.EntrepriseDepart ?? "",
                    VilleArrivee = infos?.VilleArrivee ?? "",
                    EntrepriseArrivee = infos?.EntrepriseArrivee ?? "",
                    Duree = DateTime.UtcNow - _debutMission,
                    AUtiliseFerry = _missionAUtiliseFerry,
                    DommagesCargoPourcent = _dernierDommagesConnus
                });
            }

            _distanceMissionKm = 0;
            _dernierDommagesConnus = 0;
            SupprimerMissionEnCours();
        }

        private void SauvegarderMissionEnCours(string villeDepart, string entrepriseDepart, string villeArrivee,
            string entrepriseArrivee, double distancePrevueKm)
        {
            try
            {
                var snapshot = new MissionEnCours
                {
                    VilleDepart = villeDepart,
                    EntrepriseDepart = entrepriseDepart,
                    VilleArrivee = villeArrivee,
                    EntrepriseArrivee = entrepriseArrivee,
                    DistancePrevueKm = distancePrevueKm,
                    DistanceParcourueKm = _distanceMissionKm,
                    AUtiliseFerry = _missionAUtiliseFerry,
                    DebutReel = _debutMission.ToString("o")
                };
                File.WriteAllText(_cheminMissionEnCours, JsonSerializer.Serialize(snapshot));
            }
            catch { /* pas bloquant si l'écriture échoue ponctuellement */ }
        }

        private MissionEnCours? ChargerMissionEnCours()
        {
            try
            {
                if (!File.Exists(_cheminMissionEnCours))
                    return null;
                return JsonSerializer.Deserialize<MissionEnCours>(File.ReadAllText(_cheminMissionEnCours));
            }
            catch
            {
                return null;
            }
        }

        private void RepredreMissionEnCoursSiPresente()
        {
            // Au lancement, s'il existe une mission persistée, on prépare déjà
            // les compteurs : dès que le jeu renverra OnJob=true pour la même
            // mission, DemarrerMission() la reprendra automatiquement.
            var reprise = ChargerMissionEnCours();
            if (reprise == null)
                return;

            if (EssayerParserDateUtc(reprise.DebutReel, out var debut))
                _debutMission = debut;
        }

        /// <summary>
        /// Reparse une date persistée en gardant explicitement son fuseau UTC
        /// d'origine. DateTime.TryParse() seul convertit silencieusement une
        /// chaîne ISO se terminant par "Z" vers l'heure LOCALE de la machine,
        /// ce qui décalait _debutMission dans le futur (et faisait donc
        /// "reculer" le temps de trajet affiché au lieu d'avancer).
        /// </summary>
        private static bool EssayerParserDateUtc(string? valeur, out DateTime resultat)
        {
            return DateTime.TryParse(valeur, CultureInfo.InvariantCulture,
                DateTimeStyles.RoundtripKind | DateTimeStyles.AdjustToUniversal,
                out resultat);
        }

        private void SupprimerMissionEnCours()
        {
            try
            {
                if (File.Exists(_cheminMissionEnCours))
                    File.Delete(_cheminMissionEnCours);
            }
            catch { /* pas bloquant */ }
        }

        public void Dispose()
        {
            // Pas de méthode Pause() sur cette version de la librairie :
            // rien à faire explicitement, la ressource est libérée avec le processus.
        }
    }
}
