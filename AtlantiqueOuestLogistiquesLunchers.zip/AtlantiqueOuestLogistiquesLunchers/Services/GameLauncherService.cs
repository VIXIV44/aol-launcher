using System.Diagnostics;

namespace AtlantiqueOuestLogistiquesLunchers.Services
{
    public class GameLauncherService
    {
        private readonly string _cheminExeJeu;
        private readonly ConfigService _configService;

        public GameLauncherService(string cheminExeJeu, ConfigService configService)
        {
            _cheminExeJeu = cheminExeJeu;
            _configService = configService;
        }

        public void LancerJeu()
        {
            _configService.AppliquerParametres();

            Process.Start(new ProcessStartInfo(_cheminExeJeu)
            {
                UseShellExecute = true
            });
        }
    }
}
