using System;
using System.IO;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using AtlantiqueOuestLogistiquesLunchers.Services;

namespace AtlantiqueOuestLogistiquesLunchers.Services
{
    /// <summary>
    /// Génère un document CMR (bon de transport) stylisé en PDF pour chaque
    /// mission livrée avec succès. Enregistré dans Documents\AOL-CMR\ pour
    /// être facile à retrouver par le joueur.
    /// </summary>
    public static class CmrGenerator
    {
        public static string Generer(MissionTermineeInfo mission, int numeroDocument)
        {
            string dossier = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "AOL-CMR");
            Directory.CreateDirectory(dossier);

            string nomFichier = $"CMR_{DateTime.Now:yyyyMMdd_HHmmss}.pdf";
            string cheminComplet = Path.Combine(dossier, nomFichier);

            Document.Create(conteneur =>
            {
                conteneur.Page(page =>
                {
                    page.Size(PageSizes.A4);
                    page.Margin(36);
                    page.DefaultTextStyle(x => x.FontSize(11));

                    page.Header().Column(colonne =>
                    {
                        colonne.Item().Row(ligne =>
                        {
                            ligne.RelativeItem().Column(c =>
                            {
                                c.Item().Text("ATLANTIQUE OUEST LOGISTIQUES").Bold().FontSize(18);
                                c.Item().Text("Lettre de voiture internationale (CMR)").FontSize(10).FontColor(Colors.Grey.Darken1);
                            });
                            ligne.ConstantItem(120).AlignRight().Text($"N° {numeroDocument:D6}").Bold().FontSize(12);
                        });
                        colonne.Item().PaddingTop(8).LineHorizontal(1).LineColor(Colors.Grey.Lighten1);
                    });

                    page.Content().PaddingVertical(16).Column(colonne =>
                    {
                        colonne.Spacing(14);

                        colonne.Item().Row(ligne =>
                        {
                            ligne.RelativeItem().Border(1).BorderColor(Colors.Grey.Lighten2).Padding(10).Column(c =>
                            {
                                c.Item().Text("1. EXPÉDITEUR").Bold().FontSize(9).FontColor(Colors.Grey.Darken1);
                                c.Item().PaddingTop(4).Text(mission.VilleDepart).FontSize(13);
                                c.Item().Text(mission.EntrepriseDepart).FontColor(Colors.Grey.Darken1);
                            });
                            ligne.ConstantItem(14);
                            ligne.RelativeItem().Border(1).BorderColor(Colors.Grey.Lighten2).Padding(10).Column(c =>
                            {
                                c.Item().Text("2. DESTINATAIRE").Bold().FontSize(9).FontColor(Colors.Grey.Darken1);
                                c.Item().PaddingTop(4).Text(mission.VilleArrivee).FontSize(13);
                                c.Item().Text(mission.EntrepriseArrivee).FontColor(Colors.Grey.Darken1);
                            });
                        });

                        colonne.Item().Border(1).BorderColor(Colors.Grey.Lighten2).Padding(10).Column(c =>
                        {
                            c.Item().Text("3. DÉTAILS DU TRANSPORT").Bold().FontSize(9).FontColor(Colors.Grey.Darken1);
                            c.Item().PaddingTop(6).Row(r =>
                            {
                                r.RelativeItem().Text($"Distance parcourue : {mission.DistanceKm:0} km");
                                r.RelativeItem().Text($"Durée du trajet : {(int)mission.Duree.TotalHours} h {mission.Duree.Minutes:00} min");
                            });
                            c.Item().PaddingTop(4).Row(r =>
                            {
                                r.RelativeItem().Text($"Via ferry : {(mission.AUtiliseFerry ? "Oui" : "Non")}");
                                r.RelativeItem().Text($"Date de livraison : {DateTime.Now:dd/MM/yyyy HH:mm}");
                            });
                            if (mission.DommagesCargoPourcent > 0)
                            {
                                c.Item().PaddingTop(4).Text($"Dégâts marchandise constatés : {mission.DommagesCargoPourcent:0.0} %")
                                    .FontColor(Colors.Red.Darken1);
                            }
                        });

                        colonne.Item().Border(1).BorderColor(Colors.Grey.Lighten2).Padding(10).Column(c =>
                        {
                            c.Item().Text("4. RÉMUNÉRATION").Bold().FontSize(9).FontColor(Colors.Grey.Darken1);
                            c.Item().PaddingTop(6).Text($"{mission.Gain:0.00} €").FontSize(20).Bold().FontColor(Colors.Green.Darken2);
                            if (mission.DommagesCargoPourcent > 0)
                            {
                                c.Item().PaddingTop(4).Text("Pénalité de dégâts non déduite de ce montant (information non fiable via télémétrie).")
                                    .FontSize(7).Italic().FontColor(Colors.Grey.Darken1);
                            }
                        });

                        colonne.Item().PaddingTop(20).Row(ligne =>
                        {
                            ligne.RelativeItem().Column(c =>
                            {
                                c.Item().Text("Signature de l'expéditeur").FontSize(9).FontColor(Colors.Grey.Darken1);
                                c.Item().PaddingTop(30).LineHorizontal(0.5f).LineColor(Colors.Grey.Lighten2);
                            });
                            ligne.ConstantItem(30);
                            ligne.RelativeItem().Column(c =>
                            {
                                c.Item().Text("Signature du transporteur").FontSize(9).FontColor(Colors.Grey.Darken1);
                                c.Item().PaddingTop(30).LineHorizontal(0.5f).LineColor(Colors.Grey.Lighten2);
                            });
                        });
                    });

                    page.Footer().AlignCenter().Text(t =>
                    {
                        t.Span("Document généré automatiquement par le launcher Atlantique Ouest Logistiques — usage roleplay uniquement.")
                            .FontSize(8).FontColor(Colors.Grey.Medium);
                    });
                });
            }).GeneratePdf(cheminComplet);

            return cheminComplet;
        }
    }
}
