using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using AtlantiqueOuestLogistiquesLunchers.Models;

namespace AtlantiqueOuestLogistiquesLunchers.Services
{
    /// <summary>
    /// Vérifie et applique les mises à jour du launcher lui-même.
    ///
    /// Fonctionnement (même principe qu'un launcher de jeu classique type
    /// TruckersMP) :
    /// 1. Au démarrage, le launcher télécharge un petit fichier version.json
    ///    (hébergé où tu veux) et compare le numéro de version avec la sienne.
    /// 2. Si une version plus récente existe, un bandeau propose de mettre à jour.
    /// 3. En cliquant, le launcher télécharge le nouvel .exe, puis lance un
    ///    script qui attend la fermeture du launcher actuel, remplace l'ancien
    ///    .exe par le nouveau, et le relance automatiquement.
    ///
    /// Pour publier une mise à jour : republie l'exe (voir README), héberge-le
    /// quelque part, puis mets à jour ton fichier version.json distant avec le
    /// nouveau numéro de version et le lien vers ce nouvel exe. Tous les
    /// launchers déjà installés la détecteront automatiquement au prochain lancement.
    /// </summary>
    public class UpdateService
    {
        /// <summary>
        /// Version actuelle de CE launcher. À incrémenter à chaque nouvelle
        /// publication, avant de générer l'exe (voir README section publication).
        /// </summary>
        public const string VersionActuelle = "1.0.0";

        private readonly string _urlVersion;
        private readonly HttpClient _client = new HttpClient();

        public UpdateService(string urlVersion)
        {
            _urlVersion = urlVersion;
        }

        public async Task<InfoMiseAJour?> VerifierMiseAJourAsync()
        {
            if (string.IsNullOrWhiteSpace(_urlVersion))
                return null;

            try
            {
                string json = await _client.GetStringAsync(_urlVersion);
                var info = JsonSerializer.Deserialize<InfoMiseAJour>(json);

                if (info != null
                    && !string.IsNullOrWhiteSpace(info.DerniereVersion)
                    && info.DerniereVersion != VersionActuelle)
                {
                    return info;
                }
            }
            catch
            {
                // Pas de connexion, URL non configurée ou serveur injoignable :
                // on n'embête pas le joueur, on considère juste qu'il n'y a pas de mise à jour.
            }

            return null;
        }

        /// <summary>
        /// Télécharge le nouvel exe et programme son remplacement + redémarrage
        /// automatique, puis ferme l'application actuelle.
        /// </summary>
        public async Task TelechargerEtAppliquerMiseAJourAsync(string urlExe, IProgress<string>? progression = null)
        {
            string cheminActuel = Process.GetCurrentProcess().MainModule!.FileName!;
            string nouveauExeTemp = Path.Combine(Path.GetTempPath(), $"aol_maj_{Guid.NewGuid():N}.exe");

            progression?.Report("Téléchargement de la mise à jour...");

            using (var reponse = await _client.GetAsync(urlExe, HttpCompletionOption.ResponseHeadersRead))
            {
                reponse.EnsureSuccessStatusCode();

                using var streamEntree = await reponse.Content.ReadAsStreamAsync();
                using var streamSortie = new FileStream(nouveauExeTemp, FileMode.Create, FileAccess.Write);
                await streamEntree.CopyToAsync(streamSortie);
            }

            progression?.Report("Installation de la mise à jour...");

            string cheminScript = Path.Combine(Path.GetTempPath(), $"aol_maj_{Guid.NewGuid():N}.bat");
            string nomProcessusActuel = Path.GetFileNameWithoutExtension(cheminActuel);

            // Attend que le launcher actuel se ferme, remplace l'exe, le relance,
            // puis s'auto-supprime.
            string contenuScript =
$@"@echo off
:attente
tasklist /fi ""imagename eq {Path.GetFileName(cheminActuel)}"" | find /i ""{Path.GetFileName(cheminActuel)}"" > nul
if not errorlevel 1 (
    timeout /t 1 /nobreak > nul
    goto attente
)
copy /y ""{nouveauExeTemp}"" ""{cheminActuel}""
del ""{nouveauExeTemp}""
start """" ""{cheminActuel}""
del ""%~f0""
";

            await File.WriteAllTextAsync(cheminScript, contenuScript);

            Process.Start(new ProcessStartInfo
            {
                FileName = cheminScript,
                UseShellExecute = true,
                WindowStyle = ProcessWindowStyle.Hidden,
                CreateNoWindow = true
            });

            System.Windows.Application.Current.Shutdown();
        }
    }
}
