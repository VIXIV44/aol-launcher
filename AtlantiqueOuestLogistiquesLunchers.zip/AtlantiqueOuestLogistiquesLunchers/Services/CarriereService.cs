using System;
using System.IO;
using System.Text.Json;
using AtlantiqueOuestLogistiquesLunchers.Models;

namespace AtlantiqueOuestLogistiquesLunchers.Services
{
    /// <summary>
    /// Suivi de carrière local (par joueur/PC) : distance parcourue et paye
    /// calculée (taux € / km configurable), avec historique persistant.
    /// </summary>
    public class CarriereService
    {
        private readonly string _cheminFichier;
        private readonly double _tauxParKm;

        public DonneesCarriere Donnees { get; private set; }

        public CarriereService(double tauxParKm)
        {
            _tauxParKm = tauxParKm;
            _cheminFichier = Path.Combine(AppContext.BaseDirectory, "carriere_data.json");
            Donnees = Charger();
        }

        private DonneesCarriere Charger()
        {
            if (!File.Exists(_cheminFichier))
                return new DonneesCarriere();

            try
            {
                string json = File.ReadAllText(_cheminFichier);
                return JsonSerializer.Deserialize<DonneesCarriere>(json) ?? new DonneesCarriere();
            }
            catch
            {
                return new DonneesCarriere();
            }
        }

        public void Sauvegarder()
        {
            string json = JsonSerializer.Serialize(Donnees, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_cheminFichier, json);
        }

        /// <summary>Calcule la paye pour une distance donnée, selon le taux configuré.</summary>
        public double CalculerGain(double distanceKm) => distanceKm * _tauxParKm;

        /// <summary>
        /// Enregistre une mission livrée dans l'historique, met à jour les totaux,
        /// et génère automatiquement le CMR en PDF correspondant.
        /// </summary>
        public TrajetHistorique EnregistrerMission(MissionTermineeInfo mission)
        {
            // Choix du joueur : refléter le vrai revenu du jeu (bonus/pénalités
            // inclus), capturé par TelemetryService au moment de la livraison,
            // plutôt que notre propre calcul par tarif fixe. Moins prévisible,
            // mais plus fidèle à ce que le jeu affiche réellement.
            double gain = mission.Gain;

            Donnees.DistanceTotaleKm += mission.DistanceKm;
            Donnees.GainsTotaux += gain;

            var trajet = new TrajetHistorique
            {
                Date = DateTime.Now,
                DistanceKm = mission.DistanceKm,
                Gain = gain,
                VilleDepart = mission.VilleDepart,
                EntrepriseDepart = mission.EntrepriseDepart,
                VilleArrivee = mission.VilleArrivee,
                EntrepriseArrivee = mission.EntrepriseArrivee,
                DureeMinutes = mission.Duree.TotalMinutes,
                AUtiliseFerry = mission.AUtiliseFerry,
                DommagesCargoPourcent = mission.DommagesCargoPourcent,
                RevenuJeu = mission.Gain
            };

            try
            {
                trajet.CheminCmr = CmrGenerator.Generer(mission, Donnees.Historique.Count + 1);
            }
            catch
            {
                // La génération du CMR ne doit jamais empêcher l'enregistrement du trajet.
            }

            Donnees.Historique.Insert(0, trajet);

            // Garde un historique raisonnable (les 100 derniers trajets)
            if (Donnees.Historique.Count > 100)
                Donnees.Historique.RemoveRange(100, Donnees.Historique.Count - 100);

            Sauvegarder();
            return trajet;
        }
    }
}
