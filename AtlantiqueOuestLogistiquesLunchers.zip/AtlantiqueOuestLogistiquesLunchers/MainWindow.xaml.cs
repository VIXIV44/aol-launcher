using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using AtlantiqueOuestLogistiquesLunchers.Models;
using AtlantiqueOuestLogistiquesLunchers.Services;
using AtlantiqueOuestLogistiquesLunchers.Views;

namespace AtlantiqueOuestLogistiquesLunchers
{
    public partial class MainWindow : Window
    {
        private InfoMiseAJour? _miseAJourDisponible;

        // Service de télémétrie créé une seule fois, dès le lancement du launcher
        // (pas seulement à l'ouverture de l'onglet Ma Carrière) : ainsi, le suivi
        // de distance démarre dès que le launcher tourne, pas seulement une fois
        // l'onglet consulté pour la première fois.
        private readonly TelemetryService _telemetryService = new TelemetryService();

        // Chaque vue est créée une seule fois puis réutilisée : si on la recréait
        // à chaque clic de menu, un téléchargement en cours sur la page "Mod /
        // Téléchargement" perdrait son affichage de progression dès qu'on change
        // de page (même si le téléchargement continuait techniquement en fond).
        private LancementTelechargementView? _vueLancement;
        private ModTelechargementView? _vueModTelechargement;
        private CarteInteractiveView? _vueCarte;
        private NotreHistoireView? _vueHistoire;
        private ConseilAidesView? _vueConseils;
        private CarrierePayeView? _vueCarriere;

        public MainWindow()
        {
            InitializeComponent();
            GenererChampEtoiles();
            TxtVersion.Text = $"v{UpdateService.VersionActuelle}";
            InstallerPluginTelemetrieSiBesoin();
            _vueLancement = new LancementTelechargementView();
            ZoneContenu.Content = _vueLancement;
            MettreEnSurbrillance(BtnLancement);

            _ = VerifierMiseAJourAsync();
        }

        /// <summary>
        /// Copie automatiquement le plug-in de télémétrie (scs-telemetry.dll,
        /// nécessaire à l'onglet Ma Carrière) dans le dossier plugins du jeu,
        /// s'il n'y est pas déjà — le joueur n'a rien à faire manuellement.
        /// </summary>
        private void InstallerPluginTelemetrieSiBesoin()
        {
            try
            {
                var settings = AppSettings.Charger();
                string? dossierJeu = System.IO.Path.GetDirectoryName(settings.CheminExeJeu);
                if (string.IsNullOrEmpty(dossierJeu))
                    return;

                string cheminPluginSource = System.IO.Path.Combine(AppContext.BaseDirectory, "scs-telemetry.dll");
                if (!File.Exists(cheminPluginSource))
                    return;

                string dossierPlugins = System.IO.Path.Combine(dossierJeu, "plugins");
                string cheminPluginCible = System.IO.Path.Combine(dossierPlugins, "scs-telemetry.dll");

                if (!File.Exists(cheminPluginCible))
                {
                    Directory.CreateDirectory(dossierPlugins);
                    File.Copy(cheminPluginSource, cheminPluginCible, overwrite: false);
                }
            }
            catch
            {
                // On ne bloque jamais le lancement de l'app pour ça (ex. dossier
                // du jeu introuvable, droits insuffisants...). L'onglet Carrière
                // affichera simplement "jeu non détecté" si le plug-in manque.
            }
        }

        private async System.Threading.Tasks.Task VerifierMiseAJourAsync()
        {
            var settings = AppSettings.Charger();
            var updateService = new UpdateService(settings.UrlVersion);

            var info = await updateService.VerifierMiseAJourAsync();
            if (info == null)
                return;

            _miseAJourDisponible = info;
            TxtMiseAJour.Text = $"🔄 Une mise à jour du launcher est disponible (v{info.DerniereVersion}).";
            BanniereMiseAJour.Visibility = Visibility.Visible;
        }

        private async void BtnMettreAJour_Click(object sender, RoutedEventArgs e)
        {
            if (_miseAJourDisponible == null)
                return;

            BtnMettreAJour.IsEnabled = false;
            var settings = AppSettings.Charger();
            var updateService = new UpdateService(settings.UrlVersion);

            try
            {
                var progression = (IProgress<string>)new Progress<string>(msg => TxtMiseAJour.Text = msg);
                await updateService.TelechargerEtAppliquerMiseAJourAsync(_miseAJourDisponible.UrlTelechargementExe, progression);
            }
            catch (Exception ex)
            {
                TxtMiseAJour.Text = $"Erreur lors de la mise à jour : {ex.Message}";
                BtnMettreAJour.IsEnabled = true;
            }
        }

        /// <summary>
        /// Génère un champ d'étoiles statique sur un canevas virtuel de taille fixe.
        /// Le Viewbox parent (Stretch="Fill") s'occupe de l'étirer pour couvrir toute
        /// la fenêtre, y compris en plein écran/maximisé — pas besoin de régénérer
        /// les étoiles au redimensionnement.
        /// </summary>
        private void GenererChampEtoiles()
        {
            var alea = new Random(42);
            var couleurs = new[] { Colors.White, Colors.White, Colors.White, (Color)ColorConverter.ConvertFromString("#22D3EE") };

            for (int i = 0; i < 220; i++)
            {
                double taille = alea.NextDouble() switch
                {
                    < 0.75 => alea.Next(1, 2),
                    < 0.95 => alea.Next(2, 3),
                    _ => alea.Next(3, 4)
                };

                var etoile = new Ellipse
                {
                    Width = taille,
                    Height = taille,
                    Fill = new SolidColorBrush(couleurs[alea.Next(couleurs.Length)]),
                    Opacity = 0.25 + alea.NextDouble() * 0.65
                };

                Canvas.SetLeft(etoile, alea.NextDouble() * CanvasEtoiles.Width);
                Canvas.SetTop(etoile, alea.NextDouble() * CanvasEtoiles.Height);
                CanvasEtoiles.Children.Add(etoile);

                // Scintillement : chaque étoile pulse doucement, à son propre rythme
                var animation = new DoubleAnimation
                {
                    From = etoile.Opacity,
                    To = Math.Max(0.08, etoile.Opacity - 0.35 - alea.NextDouble() * 0.3),
                    Duration = TimeSpan.FromSeconds(1.5 + alea.NextDouble() * 3.5),
                    AutoReverse = true,
                    RepeatBehavior = RepeatBehavior.Forever,
                    BeginTime = TimeSpan.FromSeconds(alea.NextDouble() * 5)
                };
                etoile.BeginAnimation(UIElement.OpacityProperty, animation);
            }
        }

        private void Naviguer_Click(object sender, RoutedEventArgs e)
        {
            var bouton = (Button)sender;

            if (bouton == BtnLancement)
                ZoneContenu.Content = _vueLancement ??= new LancementTelechargementView();
            else if (bouton == BtnOrdreMod)
                ZoneContenu.Content = _vueModTelechargement ??= new ModTelechargementView();
            else if (bouton == BtnCarte)
                ZoneContenu.Content = _vueCarte ??= new CarteInteractiveView();
            else if (bouton == BtnHistoire)
                ZoneContenu.Content = _vueHistoire ??= new NotreHistoireView();
            else if (bouton == BtnConseils)
                ZoneContenu.Content = _vueConseils ??= new ConseilAidesView();
            else if (bouton == BtnCarriere)
                ZoneContenu.Content = _vueCarriere ??= new CarrierePayeView(_telemetryService);

            MettreEnSurbrillance(bouton);
        }

        private void MettreEnSurbrillance(Button boutonActif)
        {
            var boutonMenu = (Style)FindResource("BoutonMenu");
            var boutonMenuActif = (Style)FindResource("BoutonMenuActif");

            foreach (var bouton in new[] { BtnLancement, BtnCarte, BtnOrdreMod, BtnHistoire, BtnConseils, BtnCarriere })
                bouton.Style = (bouton == boutonActif) ? boutonMenuActif : boutonMenu;
        }
    }
}
