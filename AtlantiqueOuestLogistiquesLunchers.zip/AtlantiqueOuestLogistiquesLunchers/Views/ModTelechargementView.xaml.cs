using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using AtlantiqueOuestLogistiquesLunchers.Models;
using AtlantiqueOuestLogistiquesLunchers.Services;

namespace AtlantiqueOuestLogistiquesLunchers.Views
{
    public partial class ModTelechargementView : UserControl
    {
        private readonly ModManagerService _modManagerService;
        private readonly AppSettings _settings;
        private readonly Dictionary<string, (string Url, string Libelle)> _packs;
        private readonly Dictionary<string, (Button Bouton, Border BarreFond, Border Barre, TextBlock Statut)> _elementsParPack;

        // Captures d'écran "ordre des mods" par pack, dans l'ordre à respecter
        // (de haut en bas). Liste vide = en attente des liens pour ce pack.
        private readonly Dictionary<string, List<string>> _imagesOrdreParPack;

        public ModTelechargementView()
        {
            InitializeComponent();

            _settings = AppSettings.Charger();
            _modManagerService = new ModManagerService(_settings.DossierMods, _settings.UrlManifest, _settings.UrlArchiveComplete);

            _packs = new Dictionary<string, (string, string)>
            {
                ["Bresil"] = (_settings.UrlPackBresil, "AOL Bresil"),
                ["Madeira"] = (_settings.UrlPackMadeira, "AOL Madeira"),
                ["Roumanie"] = (_settings.UrlPackRoumanie, "AOL Roumanie"),
                ["ServeurDedie"] = (_settings.UrlPackServeurDedie, "AOL Serveur Dédié"),
                ["Xxl"] = (_settings.UrlPackXxl, "AOL XXL"),
            };

            _elementsParPack = new Dictionary<string, (Button, Border, Border, TextBlock)>
            {
                ["Bresil"] = (BtnBresil, BarreBresilFond, BarreBresil, TxtStatutBresil),
                ["Madeira"] = (BtnMadeira, BarreMadeiraFond, BarreMadeira, TxtStatutMadeira),
                ["Roumanie"] = (BtnRoumanie, BarreRoumanieFond, BarreRoumanie, TxtStatutRoumanie),
                ["ServeurDedie"] = (BtnServeurDedie, BarreServeurDedieFond, BarreServeurDedie, TxtStatutServeurDedie),
                ["Xxl"] = (BtnXxl, BarreXxlFond, BarreXxl, TxtStatutXxl),
            };

            _imagesOrdreParPack = new Dictionary<string, List<string>>
            {
                ["Bresil"] = new List<string>
                {
                    "https://i.postimg.cc/HnF1pBGK/Capture-d-ecran-2026-07-26-010609.png",
                    "https://i.postimg.cc/Y2v9wPYf/Capture-d-ecran-2026-07-26-010558.png",
                    "https://i.postimg.cc/qBW7BGGT/Capture-d-ecran-2026-07-26-010542.png",
                    "https://i.postimg.cc/Bn0QHQyz/Capture-d-ecran-2026-07-26-010521.png",
                },
                ["Madeira"] = new List<string>
                {
                    "https://i.postimg.cc/kG2D11vC/Capture-d-ecran-2026-07-26-011811.png",
                    "https://i.postimg.cc/dQfhkFJM/Capture-d-ecran-2026-07-26-011801.png",
                    "https://i.postimg.cc/pLbyCBhb/Capture-d-ecran-2026-07-26-011749.png",
                },
                ["Roumanie"] = new List<string>
                {
                    "https://i.postimg.cc/BQvRyWFt/Capture-d-ecran-2026-07-26-011544.png",
                    "https://i.postimg.cc/9Q6SrrnM/Capture-d-ecran-2026-07-26-011535.png",
                    "https://i.postimg.cc/RF9DL294/Capture-d-ecran-2026-07-26-011524.png",
                    "https://i.postimg.cc/7hZtp7fp/Capture-d-ecran-2026-07-26-011511.png",
                },
                ["ServeurDedie"] = new List<string>
                {
                    "https://i.postimg.cc/HxtqydqR/Capture-d-ecran-2026-07-27-164704.png",
                    "https://i.postimg.cc/Bn1RCTWX/Capture-d-ecran-2026-07-26-011941.png",
                    "https://i.postimg.cc/1RCThCsH/Capture-d-ecran-2026-07-26-011930.png",
                    "https://i.postimg.cc/Jh56TKpC/Capture-d-ecran-2026-07-26-011920.png",
                },
                ["Xxl"] = new List<string>
                {
                    "https://i.postimg.cc/3Jynm3m5/Capture-d-ecran-2026-07-26-012204.png",
                    "https://i.postimg.cc/g28st4gX/Capture-d-ecran-2026-07-26-012153.png",
                    "https://i.postimg.cc/R0TR4hrj/Capture-d-ecran-2026-07-26-012143.png",
                    "https://i.postimg.cc/Kzv5zbxB/Capture-d-ecran-2026-07-26-012133.png",
                    "https://i.postimg.cc/SsTfYPxP/Capture-d-ecran-2026-07-26-012122.png",
                    "https://i.postimg.cc/SR7WkTYM/Capture-d-ecran-2026-07-29-230923.png",
                    "https://i.postimg.cc/ZKbN6LyD/Capture-d-ecran-2026-07-29-230907.png",
                },
            };

            PeuplerImagesOrdreMods();
            _ = MarquerPacksDejaInstallesAsync();
        }

        /// <summary>
        /// Affiche, pour chaque pack, ses captures d'écran "ordre des mods"
        /// empilées dans l'ordre fourni (haut -> bas), habillées d'une bordure
        /// arrondie et d'un badge numéroté pour s'accorder avec le thème.
        /// </summary>
        private void PeuplerImagesOrdreMods()
        {
            var conteneurs = new Dictionary<string, StackPanel>
            {
                ["Bresil"] = ImagesBresil,
                ["Madeira"] = ImagesMadeira,
                ["Roumanie"] = ImagesRoumanie,
                ["ServeurDedie"] = ImagesServeurDedie,
                ["Xxl"] = ImagesXxl,
            };

            var couleurCyan = (System.Windows.Media.Brush)FindResource("CouleurCyan");
            var couleurCyanFonce = (System.Windows.Media.Brush)FindResource("CouleurCyanFonce");
            var couleurTexteAtten = (System.Windows.Media.Brush)FindResource("CouleurTexteAtten");

            foreach (var (cle, urls) in _imagesOrdreParPack)
            {
                var conteneur = conteneurs[cle];

                if (urls.Count == 0)
                {
                    conteneur.Children.Add(new TextBlock
                    {
                        Text = "En attente des images...",
                        Foreground = couleurTexteAtten,
                        FontSize = 11,
                        TextAlignment = TextAlignment.Center,
                        Margin = new Thickness(8)
                    });
                    continue;
                }

                for (int i = 0; i < urls.Count; i++)
                {
                    var carteImage = new Border
                    {
                        Background = new System.Windows.Media.SolidColorBrush(
                            System.Windows.Media.Color.FromRgb(0x0F, 0x15, 0x24)),
                        BorderBrush = couleurCyanFonce,
                        BorderThickness = new Thickness(1),
                        CornerRadius = new CornerRadius(8),
                        Margin = new Thickness(6, 6, 6, 4),
                        Padding = new Thickness(3)
                    };

                    var grille = new Grid();
                    grille.Children.Add(new Image
                    {
                        Source = new BitmapImage(new Uri(urls[i])),
                        Stretch = System.Windows.Media.Stretch.Uniform
                    });

                    var badge = new Border
                    {
                        Width = 22,
                        Height = 22,
                        CornerRadius = new CornerRadius(11),
                        Background = couleurCyan,
                        HorizontalAlignment = HorizontalAlignment.Left,
                        VerticalAlignment = VerticalAlignment.Top,
                        Margin = new Thickness(-8, -8, 0, 0),
                        Effect = (System.Windows.Media.Effects.Effect)FindResource("LueurCyan")
                    };
                    badge.Child = new TextBlock
                    {
                        Text = (urls.Count - i).ToString(),
                        FontSize = 11,
                        FontWeight = FontWeights.Bold,
                        Foreground = System.Windows.Media.Brushes.Black,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment = VerticalAlignment.Center
                    };

                    grille.Children.Add(badge);
                    carteImage.Child = grille;
                    conteneur.Children.Add(carteImage);
                }
            }
        }

        /// <summary>
        /// Grise et relabellise les boutons des packs déjà installés précédemment,
        /// pour éviter qu'un joueur ne retélécharge par erreur plusieurs Go déjà en place.
        /// </summary>
        private async System.Threading.Tasks.Task MarquerPacksDejaInstallesAsync()
        {
            foreach (var (cle, (_, libelle)) in _packs)
            {
                if (await ModManagerService.EstPackInstalleAsync(libelle))
                {
                    var (bouton, _, _, statut) = _elementsParPack[cle];
                    MarquerCommeInstalle(bouton, statut);
                }
            }
        }

        private static void MarquerCommeInstalle(Button bouton, TextBlock statut)
        {
            bouton.Content = "✓ Déjà installé";
            bouton.IsEnabled = false;
            statut.Text = "Ce pack est déjà installé dans ton dossier mod.";
        }

        private async void BtnTelechargerPack_Click(object sender, RoutedEventArgs e)
        {
            var bouton = (Button)sender;
            string cle = (string)bouton.Tag;
            var (url, libelle) = _packs[cle];
            var (_, barreFond, barre, statut) = _elementsParPack[cle];

            bouton.IsEnabled = false;
            barreFond.Visibility = Visibility.Visible;
            barre.Width = 0;
            statut.Text = "Démarrage...";

            var progression = (IProgress<EtatTelechargement>)new Progress<EtatTelechargement>(etat =>
            {
                statut.Text = etat.Message;
                if (etat.Pourcentage.HasValue)
                    barre.Width = barreFond.ActualWidth * (etat.Pourcentage.Value / 100.0);
            });

            try
            {
                await _modManagerService.TelechargerEtInstallerPackAsync(url, libelle, progression);
                MarquerCommeInstalle(bouton, statut);
            }
            catch (Exception ex)
            {
                statut.Text = $"Erreur : {ex.Message}";
                bouton.IsEnabled = true;
            }
        }
        private async void BtnMettreAJourProMods_Click(object sender, RoutedEventArgs e)
        {
            BtnProMods.IsEnabled = false;
            BarreProModsFond.Visibility = Visibility.Visible;
            BarreProMods.Width = 0;
            TxtStatutProMods.Text = "Démarrage...";

            var progression = (IProgress<EtatTelechargement>)new Progress<EtatTelechargement>(etat =>
            {
                TxtStatutProMods.Text = etat.Message;
                if (etat.Pourcentage.HasValue)
                    BarreProMods.Width = BarreProModsFond.ActualWidth * (etat.Pourcentage.Value / 100.0);
            });

            try
            {
                await _modManagerService.RemplacerProModsAsync(_settings.UrlPackProMods, progression);
            }
            catch (Exception ex)
            {
                TxtStatutProMods.Text = $"Erreur : {ex.Message}";
            }
            finally
            {
                // Contrairement aux autres packs : reste toujours actif,
                // pour permettre une prochaine mise à jour ProMods.
                BtnProMods.IsEnabled = true;
            }
        }
    }
}
