using System;
using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using AtlantiqueOuestLogistiquesLunchers.Models;
using AtlantiqueOuestLogistiquesLunchers.Services;

namespace AtlantiqueOuestLogistiquesLunchers.Views
{
    public partial class LancementTelechargementView : UserControl
    {
        private readonly GameLauncherService _gameLauncherService;
        private readonly ServerStatusService _serverStatusService;
        private readonly AppSettings _settings;
        private readonly DispatcherTimer _timerStatutServeur;

        public LancementTelechargementView()
        {
            InitializeComponent();

            _settings = AppSettings.Charger();

            var configService = new ConfigService(_settings.CheminConfigCfg);
            _gameLauncherService = new GameLauncherService(_settings.CheminExeJeu, configService);
            _serverStatusService = new ServerStatusService(_settings.ServeurIp, _settings.ServeurPortQuery);

            // Vérifie le statut du serveur dédié tout de suite, puis toutes les 20 secondes
            _ = RafraichirStatutServeurAsync();
            _timerStatutServeur = new DispatcherTimer { Interval = TimeSpan.FromSeconds(20) };
            _timerStatutServeur.Tick += async (s, e) => await RafraichirStatutServeurAsync();
            _timerStatutServeur.Start();
        }

        private async Task RafraichirStatutServeurAsync()
        {
            var statut = await _serverStatusService.InterrogerAsync();

            if (statut.EnLigne)
            {
                TxtStatutServeur.Text = $"🟢 EN LIGNE — {statut.NombreJoueurs}/{statut.JoueursMax} joueurs";
                TxtStatutServeur.Foreground = (System.Windows.Media.Brush)FindResource("CouleurVert");
                BordureStatutServeur.BorderBrush = (System.Windows.Media.Brush)FindResource("CouleurVert");
                BordureStatutServeur.Background = new SolidColorBrush(Color.FromRgb(0x0E, 0x2A, 0x1E));
            }
            else
            {
                TxtStatutServeur.Text = "⚡ HORS LIGNE / MAINTENANCE";
                TxtStatutServeur.Foreground = (System.Windows.Media.Brush)FindResource("CouleurRouge");
                BordureStatutServeur.BorderBrush = (System.Windows.Media.Brush)FindResource("CouleurRouge");
                BordureStatutServeur.Background = new SolidColorBrush(Color.FromRgb(0x2A, 0x14, 0x14));
            }
        }

        private void BtnLancerJeu_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _gameLauncherService.LancerJeu();
                TxtStatut.Text = "Configuration appliquée. Jeu lancé !";
            }
            catch (Exception ex)
            {
                TxtStatut.Text = $"Erreur : {ex.Message}";
            }
        }

        private void BtnSteamWorkshop_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_settings.UrlSteamWorkshop))
            {
                TxtStatut.Text = "Aucun lien Steam Workshop configuré (voir appsettings.json).";
                return;
            }

            Process.Start(new ProcessStartInfo(_settings.UrlSteamWorkshop) { UseShellExecute = true });
        }
    }

    /// <summary>
    /// Chargement des paramètres depuis appsettings.json
    /// (chemins et URLs, à adapter une fois l'hébergement des mods choisi).
    /// </summary>
    public class AppSettings
    {
        public string DossierMods { get; set; } = string.Empty;
        public string CheminConfigCfg { get; set; } = string.Empty;
        public string CheminExeJeu { get; set; } = string.Empty;
        public string UrlManifest { get; set; } = string.Empty;
        public string UrlArchiveComplete { get; set; } = string.Empty;
        public string UrlSteamWorkshop { get; set; } = string.Empty;
        public string ServeurIp { get; set; } = string.Empty;
        public int ServeurPortQuery { get; set; } = 27016;
        public string UrlVersion { get; set; } = string.Empty;
        public string UrlPackBresil { get; set; } = string.Empty;
        public string UrlPackMadeira { get; set; } = string.Empty;
        public string UrlPackRoumanie { get; set; } = string.Empty;
        public string UrlPackServeurDedie { get; set; } = string.Empty;
        public string UrlPackXxl { get; set; } = string.Empty;
        public string UrlPackProMods { get; set; } = string.Empty;
        public double TauxParKm { get; set; } = 0.5;

        public static AppSettings Charger()
        {
            string chemin = Path.Combine(AppContext.BaseDirectory, "appsettings.json");

            if (!File.Exists(chemin))
                return new AppSettings();

            string json = File.ReadAllText(chemin);
            var settings = JsonSerializer.Deserialize<AppSettings>(json) ?? new AppSettings();

            // Résout les variables d'environnement type %USERPROFILE% dans les chemins
            settings.DossierMods = Environment.ExpandEnvironmentVariables(settings.DossierMods);
            settings.CheminConfigCfg = Environment.ExpandEnvironmentVariables(settings.CheminConfigCfg);
            settings.CheminExeJeu = Environment.ExpandEnvironmentVariables(settings.CheminExeJeu);

            return settings;
        }
    }
}
