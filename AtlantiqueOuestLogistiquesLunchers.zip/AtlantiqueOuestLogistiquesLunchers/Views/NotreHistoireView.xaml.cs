using System.Windows.Controls;

namespace AtlantiqueOuestLogistiquesLunchers.Views
{
    public partial class NotreHistoireView : UserControl
    {
        public NotreHistoireView()
        {
            InitializeComponent();
        }
    }
}
