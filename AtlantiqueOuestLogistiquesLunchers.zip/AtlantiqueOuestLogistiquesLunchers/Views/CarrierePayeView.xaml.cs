using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using AtlantiqueOuestLogistiquesLunchers.Models;
using AtlantiqueOuestLogistiquesLunchers.Services;

namespace AtlantiqueOuestLogistiquesLunchers.Views
{
    public class LigneHistorique
    {
        public string TexteDate { get; set; } = string.Empty;
        public string TexteDistance { get; set; } = string.Empty;
        public string TexteGain { get; set; } = string.Empty;
        public string TexteItineraire { get; set; } = string.Empty;
        public Visibility VisibiliteItineraire { get; set; } = Visibility.Collapsed;
        public string CheminCmr { get; set; } = string.Empty;
    }

    public partial class CarrierePayeView : UserControl
    {
        private readonly CarriereService _carriereService;
        private readonly TelemetryService _telemetryService;

        public CarrierePayeView(TelemetryService telemetryService)
        {
            InitializeComponent();

            var settings = AppSettings.Charger();
            _carriereService = new CarriereService(settings.TauxParKm);
            _telemetryService = telemetryService;
            _telemetryService.SurMiseAJour += Telemetrie_SurMiseAJour;
            _telemetryService.SurMissionTerminee += Telemetrie_SurMissionTerminee;

            RafraichirTotaux();
            RafraichirHistorique();
        }

        private void Telemetrie_SurMiseAJour(EtatTelemetrie etat)
        {
            // Les évènements de télémétrie arrivent sur un thread en arrière-plan :
            // on repasse sur le thread UI pour mettre à jour les contrôles.
            Dispatcher.Invoke(() =>
            {
                if (!etat.SdkActif)
                {
                    TxtEtatSdk.Text = "⚠ Jeu non détecté — vérifie que le plug-in de télémétrie est installé et que le jeu est lancé.";
                    return;
                }

                TxtEtatSdk.Text = "🟢 Télémétrie connectée.";

                if (etat.EnTrajet)
                {
                    TxtTitreMission.Text = "🚚 MISSION EN COURS";
                    TxtItineraire.Text = $"{etat.VilleDepart} ({etat.EntrepriseDepart}) → {etat.VilleArrivee} ({etat.EntrepriseArrivee})";
                }
                else
                {
                    TxtTitreMission.Text = "AUCUNE MISSION EN COURS";
                    TxtItineraire.Text = "Accepte un contrat dans le jeu pour démarrer le suivi automatique.";
                }

                BadgeFerry.Visibility = etat.EnFerry ? Visibility.Visible : Visibility.Collapsed;

                if (etat.DommagesCargoPourcent > 0)
                {
                    BadgeDommages.Visibility = Visibility.Visible;
                    TxtDommages.Text = $"⚠ Dégâts marchandise constatés : {etat.DommagesCargoPourcent:0.0} % (pénalité non déduite du montant affiché)";
                }
                else
                {
                    BadgeDommages.Visibility = Visibility.Collapsed;
                }

                TxtVitesse.Text = $"{etat.VitesseKmh:0} km/h";
                TxtDistanceSession.Text = $"{etat.DistanceSessionKm:0} / {etat.DistancePrevueTrajetKm:0} km";
                TxtPayeSession.Text = $"{etat.GainTrajetActuel:0.00} €";
                TxtTempsJeu.Text = etat.DureeMission.ToString(@"hh\:mm\:ss");
            });
        }

        private void Telemetrie_SurMissionTerminee(MissionTermineeInfo mission)
        {
            Dispatcher.Invoke(() =>
            {
                _carriereService.EnregistrerMission(mission);
                RafraichirTotaux();
                RafraichirHistorique();
            });
        }

        private void RafraichirTotaux()
        {
            TxtDistanceTotale.Text = $"{_carriereService.Donnees.DistanceTotaleKm:0} km";
            TxtGainsTotaux.Text = $"{_carriereService.Donnees.GainsTotaux:0.00} €";
        }

        private void RafraichirHistorique()
        {
            var lignes = new List<LigneHistorique>();
            foreach (var trajet in _carriereService.Donnees.Historique)
            {
                bool aDesInfos = !string.IsNullOrWhiteSpace(trajet.VilleDepart) || !string.IsNullOrWhiteSpace(trajet.VilleArrivee);

                lignes.Add(new LigneHistorique
                {
                    TexteDate = trajet.Date.ToString("dd/MM/yyyy HH:mm", CultureInfo.GetCultureInfo("fr-FR")),
                    TexteDistance = $"{trajet.DistanceKm:0} km",
                    TexteGain = $"{trajet.Gain:0.00} €",
                    TexteItineraire = aDesInfos
                        ? $"{trajet.VilleDepart} ({trajet.EntrepriseDepart}) → {trajet.VilleArrivee} ({trajet.EntrepriseArrivee})"
                            + (trajet.AUtiliseFerry ? "  🚢" : "")
                            + (trajet.DommagesCargoPourcent > 0 ? $"  ⚠ {trajet.DommagesCargoPourcent:0.0}% dégâts" : "")
                        : "",
                    VisibiliteItineraire = aDesInfos ? Visibility.Visible : Visibility.Collapsed,
                    CheminCmr = trajet.CheminCmr
                });
            }

            ListeHistorique.ItemsSource = lignes;
            TxtAucunHistorique.Visibility = lignes.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        }

        private void BtnOuvrirCmr_Click(object sender, RoutedEventArgs e)
        {
            var bouton = (Button)sender;
            string chemin = (string)bouton.Tag;

            if (string.IsNullOrWhiteSpace(chemin) || !System.IO.File.Exists(chemin))
            {
                TxtEtatSdk.Text = "CMR introuvable (peut-être supprimé manuellement).";
                return;
            }

            Process.Start(new ProcessStartInfo(chemin) { UseShellExecute = true });
        }
    }
}
