# Atlantique Ouest Logistiques Lunchers

Launcher WPF (.NET 8) pour Euro Truck Simulator 2.

## Ouvrir le projet

1. Installe **.NET 8 SDK** si ce n'est pas déjà fait : https://dotnet.microsoft.com/download
2. Ouvre `AtlantiqueOuestLogistiquesLunchers.csproj` directement avec Visual Studio 2022
   (menu Fichier > Ouvrir > Projet/Solution).
3. Compile (Ctrl+Maj+B) puis lance (F5).

## Avant de lancer

Édite `appsettings.json` (à la racine du projet) :

- `DossierMods` : dossier où sont installés les mods (par défaut `Documents\Euro Truck Simulator 2\mod`)
- `CheminConfigCfg` : chemin vers `config.cfg`
- `CheminExeJeu` : chemin vers `eurotrucks2.exe` (à adapter selon où Steam a installé le jeu)
- `UrlManifest` : URL vers ton fichier `manifest.json` (liste des mods attendus)
- `UrlArchiveComplete` : URL vers l'archive zip complète des mods
- `UrlSteamWorkshop` : lien vers ta collection Steam Workshop

⚠️ **`UrlManifest` et `UrlArchiveComplete` sont vides pour l'instant** (hébergement pas encore choisi).
Tant qu'ils ne pointent pas vers de vraies URLs, le bouton "Télécharger / Vérifier les mods" plantera.
Utilise `manifest.example.json` comme modèle pour le format attendu.

## Vérifier les clés du config.cfg

Le fichier `Services/ConfigService.cs` cherche les lignes `uset g_convoy_size` et
`uset g_buffer_size`. Ouvre ton propre `config.cfg` (Bloc-notes) et vérifie que
ces noms de clés correspondent bien à ta version du jeu — sinon adapte le code.

## Ma Carrière (kilomètres / paye / CMR)

Onglet qui lit la télémétrie du jeu en direct et suit **automatiquement le cycle de vie de
chaque mission** (dès qu'un contrat est accepté jusqu'à sa livraison) — pas de bouton
"démarrer/terminer" manuel. Portée **locale** : chaque joueur ne voit que ses propres
statistiques, stockées sur son PC.

**Ce qui est suivi automatiquement par mission :**
- Distance réellement parcourue (odomètre), comparée à la distance prévue du contrat
- Temps de trajet réel (du moment où le contrat est accepté à la livraison)
- Ville/entreprise de départ et d'arrivée
- Utilisation d'un ferry pendant le trajet (badge 🚢 affiché en direct)
- Revenu du contrat (celui du jeu) + paye calculée par le launcher (taux €/km configurable)

**Persistance si le jeu/launcher est fermé en pleine mission** : la progression est
sauvegardée sur le disque toutes les 5 secondes (`mission_en_cours.json`). Si tu fermes le
jeu ou le launcher avant la livraison, la distance déjà parcourue est reprise au prochain
lancement (tant que c'est bien la même mission — même ville/entreprise de départ et
d'arrivée) au lieu de repartir de zéro.

**CMR en PDF** : dès qu'une mission est livrée avec succès, un document CMR (lettre de
voiture) stylisé est généré automatiquement dans `Documents\AOL-CMR\`, et un bouton
"📄 CMR" apparaît sur la ligne correspondante de l'historique pour le rouvrir à tout moment.
Généré via [QuestPDF](https://www.questpdf.com/) (licence Community gratuite pour ce genre
d'usage, déjà configurée dans `App.xaml.cs`).

Ça s'appuie sur le plug-in de télémétrie officiel de SCS, via la librairie communautaire
[RenCloud/scs-sdk-plugin](https://github.com/RenCloud/scs-sdk-plugin) (standard de facto pour
ce genre d'intégration ETS2/ATS). Les fichiers nécessaires (`Libs\SCSSdkClient.dll` et
`Assets\scs-telemetry.dll`) sont **déjà inclus** dans ce projet — rien à télécharger.

**Installation automatique côté joueur** : au premier lancement du launcher, le plug-in
`scs-telemetry.dll` est copié tout seul dans le dossier `plugins` du jeu (créé s'il n'existe
pas). ETS2 affichera un message "SDK activé" à chaque lancement (normal, juste pour prévenir
que le plug-in est actif).

`Newtonsoft.Json` (dépendance de SCSSdkClient) et `QuestPDF` sont restaurés automatiquement via NuGet.

### Point d'attention

Certains noms de propriétés exacts dans `Services/TelemetryService.cs` (`Odometer`,
`SpecialEventsValues.OnJob`, `SpecialEventsValues.Ferry`, `CitySource`...) s'appuient sur la
documentation communautaire du projet plutôt que sur un test direct de ma part (je n'ai pas
d'environnement Windows pour vérifier). Si Visual Studio signale qu'un nom de propriété
n'existe pas, envoie-moi l'erreur et je corrige immédiatement.

Le temps de trajet est mesuré en **temps réel (horloge du PC)**, pas en temps simulé du jeu
(qui s'écoule plus vite) — plus simple et plus robuste à vérifier, mais dis-le moi si tu
préfères vraiment le temps in-game.

### Configuration

Dans `appsettings.json` : `TauxParKm` (défaut `0.5`) — le montant en euros versé par
kilomètre parcouru, modifiable librement. Ce montant sert au calcul "Paye" du launcher ;
le "Revenu du contrat" affiché sur le CMR reste celui du jeu.

## Rendre le launcher téléchargeable (un seul .exe)

Un profil de publication est déjà configuré dans le projet. Pour générer un `.exe` autonome
que tes joueurs pourront télécharger et lancer sans installer Visual Studio ni le SDK .NET :

1. Dans Visual Studio : clic droit sur le projet **AtlantiqueOuestLogistiquesLunchers**
   dans l'Explorateur de solutions → **Publier...**
2. Choisis **Dossier** comme cible, puis **Suivant** jusqu'à la fin (le profil déjà
   configuré — Windows x64, autonome, fichier unique — sera proposé automatiquement)
3. Clique sur **Publier**
4. Le fichier `.exe` (et `appsettings.json` à côté) se trouve dans :
   `bin\Release\net8.0-windows\publish\`
5. Zippe ce dossier (ou juste `AtlantiqueOuestLogistiquesLunchers.exe` +
   `appsettings.json`) et partage-le où tu veux (Discord, Google Drive, GitHub, etc.)

⚠️ Le `.exe` fait plusieurs dizaines de Mo car il embarque le runtime .NET (c'est ce
qui permet à tes joueurs de le lancer sans rien installer). N'oublie pas de mettre à
jour `appsettings.json` avec tes vraies URLs avant de publier.

## Mise à jour automatique des launchers déjà installés

Même principe qu'un launcher de jeu classique (TruckersMP et autres) : quand tu publies
une nouvelle version, tous les launchers déjà installés chez tes joueurs la détectent
tout seuls et proposent de se mettre à jour — pas besoin que chacun retélécharge
manuellement.

**Comment ça marche :**
1. Au démarrage, le launcher va lire un petit fichier `version.json` que tu héberges
   (voir `UrlVersion` dans `appsettings.json`, vide pour l'instant)
2. S'il contient un numéro de version différent de la sienne, un bandeau apparaît en
   haut : *"Une mise à jour est disponible"* avec un bouton
3. En cliquant, il télécharge le nouvel `.exe`, puis se ferme, se remplace lui-même,
   et se relance automatiquement

**Format attendu du fichier `version.json` :**
```json
{
  "DerniereVersion": "1.0.1",
  "UrlTelechargementExe": "https://.../AtlantiqueOuestLogistiquesLunchers.exe",
  "Notes": "Correctif mineur"
}
```

**Où héberger ce fichier + les futurs .exe ?** Le plus simple et gratuit : un dépôt
GitHub public avec les releases (chaque `.exe` publié devient une "Release" avec un
lien stable), et `version.json` hébergé en "raw" dans le même dépôt
(`https://raw.githubusercontent.com/<toi>/<repo>/main/version.json`). Mais n'importe
quel hébergement avec une URL stable fonctionne (ton propre serveur, etc.).

**À chaque nouvelle version que tu publies :**
1. Incrémente `VersionActuelle` dans `Services/UpdateService.cs` (ex. `"1.0.1"`)
2. Republie l'exe (voir section ci-dessus)
3. Héberge ce nouvel exe quelque part avec un lien stable
4. Mets à jour ton fichier `version.json` distant avec le nouveau numéro + le nouveau lien
5. Tous les launchers déjà installés le détecteront automatiquement au prochain lancement

## Packs de mods (onglet "Mod / Téléchargement")

5 boutons de téléchargement indépendants, un par pack (Bresil, Madeira, Roumanie,
Serveur Dédié, XXL). Chaque pack s'installe de façon additive : télécharger un pack
n'efface pas les autres déjà installés (contrairement à l'ancien système d'archive
unique). Renseigne les liens dans `appsettings.json` :

- `UrlPackBresil`
- `UrlPackMadeira`
- `UrlPackRoumanie`
- `UrlPackServeurDedie`
- `UrlPackXxl`

## Carte Interactive 3D (TrucksBook)

L'onglet affiche directement la carte en direct de [TrucksBook](https://trucksbook.eu/map)
via un navigateur embarqué (WebView2, le moteur d'Edge) — pas d'API publique disponible
pour ce site, donc c'est la vraie page qui s'affiche. Chaque joueur doit se connecter à
son propre compte TrucksBook directement dans la fenêtre pour voir la carte (et avoir
installé le "TrucksBook Client" sur son PC pour que sa position soit suivie).

**Prérequis :**
- Une connexion internet (évidemment)
- Le "WebView2 Runtime" doit être présent sur le PC du joueur — il est **déjà installé
  par défaut sur Windows 10/11** avec Edge, donc dans l'immense majorité des cas rien à
  faire. S'il manque, Windows proposera de l'installer automatiquement.
- Au premier `dotnet restore` / compilation, Visual Studio télécharge le package NuGet
  `Microsoft.Web.WebView2`. Si la version exacte indiquée dans le `.csproj` n'est plus
  disponible, ouvre le Gestionnaire de packages NuGet et installe simplement la dernière
  version stable de `Microsoft.Web.WebView2`.

## Statut serveur en temps réel

Le panneau "SERVEUR DÉDIÉ AOL" interroge ton serveur dédié ETS2 toutes les 20 secondes
via le protocole standard **A2S_INFO** (le même que les serveurs Source/Steam), directement
sur l'IP et le port de requête du serveur — **pas** via le panel fly-serv.com, qui bloque les
accès automatisés et nécessite une connexion.

Renseigne dans `appsettings.json` :
- `ServeurIp` : l'adresse IP publique de ton serveur dédié
- `ServeurPortQuery` : le port de requête (`query_dedicated_port` dans `server_config.sii`,
  27016 par défaut)

Ces deux infos sont normalement visibles dans ton panel d'hébergement fly-serv.com
(section "connexion" ou "ports" du serveur) ou dans le fichier `server_config.sii` généré
par ETS2 sur ta machine hôte.

## Logo

Déjà intégré (`Assets/logo.png`) — utilisé dans la barre latérale, en icône de fenêtre/barre
des tâches, et comme icône de l'exécutable (`Assets/app.ico`).

## Structure

```
MainWindow.xaml(.cs)              → fenêtre principale, menu latéral, navigation
Views/
  LancementTelechargementView     → onglet 1 : les 3 boutons (mods, workshop, lancer)
  ModTelechargementView            → onglet 2 : packs de mods (Bresil, Madeira, Roumanie, Serveur Dédié, XXL)
  CarteInteractiveView            → onglet 3 : squelette à compléter
  NotreHistoireView               → onglet 4 : squelette à compléter
  ConseilAidesView                → onglet 5 : squelette à compléter
Services/
  ConfigService                   → modifie config.cfg
  ModManagerService                → scan + téléchargement des mods
  GameLauncherService              → lance le jeu
Models/
  ModManifestEntry, EtapeLauncher
appsettings.json                  → chemins et URLs (à adapter)
manifest.example.json             → format attendu du manifest de mods
```

## Prochaines étapes possibles

- Définir l'hébergement des mods (serveur perso, GitHub Releases, etc.)
- Générer les vrais hash SHA-256 des mods pour le manifest
- Construire l'onglet "Ordre des mods" (liste réordonnable, glisser-déposer)
- Construire l'onglet "Carte interactive"
