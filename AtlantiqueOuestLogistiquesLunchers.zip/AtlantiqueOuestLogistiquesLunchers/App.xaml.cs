using System.Globalization;
using System.Threading;
using System.Windows;

namespace AtlantiqueOuestLogistiquesLunchers
{
    public partial class App : Application
    {
        public App()
        {
            // Force le point comme séparateur décimal partout dans l'app
            // (au lieu de la virgule habituelle en français), pour éviter
            // toute confusion dans les chiffres affichés.
            var cultureSansVirgule = (CultureInfo)CultureInfo.InvariantCulture.Clone();
            Thread.CurrentThread.CurrentCulture = cultureSansVirgule;
            Thread.CurrentThread.CurrentUICulture = cultureSansVirgule;
            CultureInfo.DefaultThreadCurrentCulture = cultureSansVirgule;
            CultureInfo.DefaultThreadCurrentUICulture = cultureSansVirgule;

            // QuestPDF (génération des CMR) exige de déclarer un type de licence
            // au démarrage. "Community" est gratuit pour un usage comme le nôtre
            // (particuliers / petites structures) — voir questpdf.com/license.
            QuestPDF.Settings.License = QuestPDF.Infrastructure.LicenseType.Community;
        }
    }
}
